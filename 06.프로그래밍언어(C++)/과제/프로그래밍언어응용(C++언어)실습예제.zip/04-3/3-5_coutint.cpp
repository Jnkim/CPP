#include <iostream>
using namespace std;

int main()
{
   int result;
   
   result = 123 + 456;
   cout << result << endl;
   
   return 0;
}