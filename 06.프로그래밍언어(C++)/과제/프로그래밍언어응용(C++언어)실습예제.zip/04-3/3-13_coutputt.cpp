#include <iostream>
using namespace std;

int main()
{
   char ch = 'A';
   
   cout.put('B');
   cout.put(ch);
   cout << endl;
   
   return 0;
}