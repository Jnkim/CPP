#include <iostream>
using namespace std;

int main()
{
   cout << "Happy\tDay\n";
   cout << "\nHe\'say, \"Good\"\n";
   cout << "C:\\Fold\\filename\n";
   
   return 0;
}