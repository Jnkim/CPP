#include <iostream>
using namespace std;
#include <climits>

int main()
{
   cout << "int ũ��: " << sizeof(int) << "bytes" << endl;
   cout << "double ũ��: " << sizeof(double) << "bytes" << endl;
   cout << "int �ִ� ũ��: " << INT_MAX << "bytes" << endl;

   return 0;
}
   