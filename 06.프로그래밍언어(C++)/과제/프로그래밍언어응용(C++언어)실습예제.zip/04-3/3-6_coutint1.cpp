#include <iostream>
using namespace std;

int main()
{
   int i = 123;
   int j = 456;
   int result;
   
   result = i + j;
   cout << result << endl;
   
   return 0;
}