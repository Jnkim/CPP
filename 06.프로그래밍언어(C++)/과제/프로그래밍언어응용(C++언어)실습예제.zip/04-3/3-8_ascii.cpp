#include <iostream>
using namespace std;

int main()
{
   float y = 65.0;
   char ch = 'B';
   cout << "����: " << ch << endl;
   cout << "�ƽ�Ű �ڵ�: " << (int) ch << endl;
   cout << "����: " << char(y) << endl;
   cout << "(char) y : " << (char) y << endl;
   cout << "float(ch): " << float(ch) << endl;
   cout << "int(ch): " << int(ch) << endl;
   system("PAUSE");
   return 0;
}
