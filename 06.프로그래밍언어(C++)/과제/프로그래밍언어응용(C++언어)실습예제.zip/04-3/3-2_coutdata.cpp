#include <iostream>
using namespace std;

int main()
{
   int x = 5;
   char ch = 'A';
   char *pt = "Vision";
   char str[] = "Love";
   
   cout << x << "\n";
   cout << ch << "\n";
   cout << "Happy\n";
   cout << pt << "\n";
   cout << str << "\n";
   
   return 0;
}