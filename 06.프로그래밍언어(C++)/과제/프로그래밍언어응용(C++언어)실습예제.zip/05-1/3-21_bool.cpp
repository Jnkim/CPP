#include <iostream>        
using namespace std;     

int main()                   
{                                        
  bool x = true;

  if(x)
      cout << "���Դϴ�.\n";
  else
      cout << "�����Դϴ�.\n";

  system("PAUSE");
  return  0;
}
