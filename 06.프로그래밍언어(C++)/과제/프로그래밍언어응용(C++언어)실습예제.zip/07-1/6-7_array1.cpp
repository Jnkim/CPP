#include <iostream>
using namespace std;

int main()
{
   int a[5] = {6, 7, 8, 9, 10};

   for(int i = 0; i < 5; i++)
      cout << "a[" << i << "] = " << a[i] << endl;
   system("PAUSE");
   return 0;
}
