#include <iostream>
using namespace std;

int main()
{
   char ch[] = {'s', 'e', 'o', 'u', 'l'};

   for(int i = 0; i < 5; i++)
      cout << "ch[" << i << "] = " << ch[i] << endl;
   system("PAUSE");
   return 0;
}
