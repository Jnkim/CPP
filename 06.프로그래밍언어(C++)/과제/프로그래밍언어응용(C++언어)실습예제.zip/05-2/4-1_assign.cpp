#include <iostream>
using namespace std;

int main()
{
  int x, y = 0;
  x = 3;
  cout << x << endl;
  x = x + 5;
  cout << x << endl;
  y = x + 7;
  cout << y << endl;
  system("PAUSE");
  return  0;
}
