#include <iostream>
using namespace std;

int main()
{
    int sum(0);     // int sum = 0;
    int count(5);   // int count = 5;
    
    cout << "sum=" << sum << endl;
    cout << "count=" << count << endl; 
    
    system("PAUSE");
    return 0;
}
